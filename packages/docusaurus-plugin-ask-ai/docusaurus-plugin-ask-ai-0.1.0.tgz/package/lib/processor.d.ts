/**
 * Document processing functions for the docusaurus-plugin-llms plugin
 */
import { DocInfo, PluginContext } from './types';
/**
 * Process a markdown file and extract its metadata and content
 * @param filePath - Path to the markdown file
 * @param baseDir - Base directory
 * @param siteUrl - Base URL of the site
 * @param pathPrefix - Path prefix for URLs (e.g., 'docs' or 'blog')
 * @param pathTransformation - Path transformation configuration
 * @returns Processed file data
 */
export declare function processMarkdownFile(filePath: string, baseDir: string, siteUrl: string, pathPrefix?: string, pathTransformation?: {
    ignorePaths?: string[];
    addPaths?: string[];
}, excludeImports?: boolean, removeDuplicateHeadings?: boolean, resolvedUrl?: string): Promise<DocInfo | null>;
export declare function processFilesWithPatterns(context: PluginContext, allFiles: string[], includePatterns?: string[], ignorePatterns?: string[], orderPatterns?: string[], includeUnmatched?: boolean): Promise<DocInfo[]>;
