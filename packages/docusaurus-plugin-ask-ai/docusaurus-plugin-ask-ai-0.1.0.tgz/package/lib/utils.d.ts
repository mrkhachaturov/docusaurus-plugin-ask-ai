/**
 * Utility functions for the docusaurus-plugin-llms plugin
 */
import { PluginOptions } from './types';
/**
 * Null/Undefined Handling Guidelines:
 *
 * 1. For required parameters: Throw early if null/undefined
 * 2. For optional parameters: Use optional chaining `value?.property`
 * 3. For explicit null checks: Use `!== null` and `!== undefined` or the isDefined type guard
 * 4. For string validation: Use isNonEmptyString() type guard
 * 5. For truthy checks on booleans: Use explicit comparison or Boolean(value)
 *
 * Avoid: `if (value)` when value could be 0, '', or false legitimately
 * Use: Type guards for consistent, type-safe checks
 */
/**
 * Type guard to check if a value is defined (not null or undefined)
 * @param value - Value to check
 * @returns True if value is not null or undefined
 */
export declare function isDefined<T>(value: T | null | undefined): value is T;
/**
 * Type guard to check if a value is a non-empty string
 * @param value - Value to check
 * @returns True if value is a string with at least one non-whitespace character
 */
export declare function isNonEmptyString(value: unknown): value is string;
/**
 * Type guard to check if a value is a non-empty array
 * @param value - Value to check
 * @returns True if value is an array with at least one element
 */
export declare function isNonEmptyArray<T>(value: unknown): value is T[];
/**
 * Safely extract an error message from an unknown error value
 * @param error - The error value (can be Error, string, or any other type)
 * @returns A string representation of the error
 */
export declare function getErrorMessage(error: unknown): string;
/**
 * Extract stack trace from unknown error types
 * @param error - The error value (can be Error or any other type)
 * @returns Stack trace if available, undefined otherwise
 */
export declare function getErrorStack(error: unknown): string | undefined;
/**
 * Custom error class for validation errors
 */
export declare class ValidationError extends Error {
    constructor(message: string);
}
/**
 * Validates that a value is not null or undefined
 * @param value - The value to validate
 * @param paramName - The parameter name for error messages
 * @returns The validated value
 * @throws ValidationError if the value is null or undefined
 */
export declare function validateRequired<T>(value: T | null | undefined, paramName: string): T;
/**
 * Validates that a value is a string and optionally checks its properties
 * @param value - The value to validate
 * @param paramName - The parameter name for error messages
 * @param options - Validation options for min/max length and pattern
 * @returns The validated string
 * @throws ValidationError if validation fails
 */
export declare function validateString(value: unknown, paramName: string, options?: {
    minLength?: number;
    maxLength?: number;
    pattern?: RegExp;
}): string;
/**
 * Validates that a value is an array and optionally validates elements
 * @param value - The value to validate
 * @param paramName - The parameter name for error messages
 * @param elementValidator - Optional function to validate each element
 * @returns The validated array
 * @throws ValidationError if validation fails
 */
export declare function validateArray<T>(value: unknown, paramName: string, elementValidator?: (item: unknown) => boolean): T[];
/**
 * Logging level enumeration
 */
export declare enum LogLevel {
    QUIET = 0,
    NORMAL = 1,
    VERBOSE = 2
}
/**
 * Set the logging level for the plugin
 * @param level - The logging level to use
 */
export declare function setLogLevel(level: LogLevel): void;
/**
 * Logger utility for consistent logging across the plugin
 */
export declare const logger: {
    error: (message: string) => void;
    warn: (message: string) => void;
    info: (message: string) => void;
    verbose: (message: string) => void;
};
/**
 * Normalizes a file path by converting all backslashes to forward slashes.
 * This ensures consistent path handling across Windows and Unix systems.
 *
 * @param filePath - The file path to normalize
 * @returns The normalized path with forward slashes
 * @throws ValidationError if filePath is not a string
 */
export declare function normalizePath(filePath: string): string;
/**
 * Validates that a file path does not exceed the platform-specific maximum length
 * @param filePath - The file path to validate
 * @returns True if the path is within limits, false otherwise
 */
export declare function validatePathLength(filePath: string): boolean;
/**
 * Shortens a file path by creating a hash-based filename if the path is too long
 * @param fullPath - The full file path that may be too long
 * @param outputDir - The output directory base path
 * @param relativePath - The relative path from the output directory
 * @returns A shortened path if necessary, or the original path if it's within limits
 */
export declare function shortenPathIfNeeded(fullPath: string, outputDir: string, relativePath: string): string;
/**
 * Write content to a file
 * @param filePath - Path to write the file to
 * @param data - Content to write
 */
export declare function writeFile(filePath: string, data: string): Promise<void>;
/**
 * Read content from a file
 * @param filePath - Path of the file to read
 * @returns Content of the file with BOM removed if present
 */
export declare function readFile(filePath: string): Promise<string>;
/**
 * Check if a file should be ignored based on glob patterns
 * Matches against both site-relative and docs-relative paths
 * @param filePath - Path to the file
 * @param baseDir - Base directory (site root) for relative paths
 * @param ignorePatterns - Glob patterns for files to ignore
 * @param docsDir - Docs directory name (e.g., 'docs')
 * @returns Whether the file should be ignored
 */
export declare function shouldIgnoreFile(filePath: string, baseDir: string, ignorePatterns: string[], docsDir?: string): boolean;
/**
 * Recursively reads all Markdown files in a directory
 * @param dir - Directory to scan
 * @param baseDir - Base directory (site root) for relative paths
 * @param ignorePatterns - Glob patterns for files to ignore
 * @param docsDir - Docs directory name (e.g., 'docs')
 * @param warnOnIgnoredFiles - Whether to warn about ignored files
 * @param visitedPaths - Set of already visited real paths to detect symlink loops (internal use)
 * @returns Array of file paths
 */
export declare function readMarkdownFiles(dir: string, baseDir: string, ignorePatterns?: string[], docsDir?: string, warnOnIgnoredFiles?: boolean, visitedPaths?: Set<string>): Promise<string[]>;
/**
 * Extract title from content or use the filename
 * @param data - Frontmatter data
 * @param content - Markdown content
 * @param filePath - Path to the file
 * @returns Extracted title
 */
export declare function extractTitle(data: any, content: string, filePath: string): string;
/**
 * Resolve and inline partial imports in markdown content
 * @param content - The markdown content with import statements
 * @param filePath - The path of the file containing the imports
 * @param importChain - Set of file paths in the current import chain (for circular dependency detection)
 * @returns Content with partials resolved
 */
export declare function resolvePartialImports(content: string, filePath: string, importChain?: Set<string>): Promise<string>;
/**
 * Clean markdown content for LLM consumption
 * @param content - Raw markdown content
 * @param excludeImports - Whether to exclude import statements
 * @param removeDuplicateHeadings - Whether to remove redundant content that duplicates heading text
 * @returns Cleaned content
 */
export declare function cleanMarkdownContent(content: string, excludeImports?: boolean, removeDuplicateHeadings?: boolean): string;
/**
 * Apply path transformations according to configuration
 * @param urlPath - Original URL path
 * @param pathTransformation - Path transformation configuration
 * @returns Transformed URL path
 */
export declare function applyPathTransformations(urlPath: string, pathTransformation?: PluginOptions['pathTransformation']): string;
/**
 * Sanitize a string to create a safe filename
 * @param input - Input string (typically a title)
 * @param fallback - Fallback string if input becomes empty after sanitization
 * @returns Sanitized filename (without extension)
 * @throws ValidationError if input or fallback are not strings
 */
export declare function sanitizeForFilename(input: string, fallback?: string, options?: {
    preserveUnicode?: boolean;
    preserveCase?: boolean;
}): string;
/**
 * Ensure a unique identifier from a set of used identifiers
 * @param baseIdentifier - Base identifier to make unique
 * @param usedIdentifiers - Set of already used identifiers
 * @param suffix - Suffix pattern (default: number in parentheses)
 * @returns Unique identifier
 * @throws ValidationError if baseIdentifier is not a string or usedIdentifiers is not a Set
 */
export declare function ensureUniqueIdentifier(baseIdentifier: string, usedIdentifiers: Set<string>, suffix?: (counter: number, base: string) => string): string;
/**
 * Create standardized markdown content template
 * @param title - Document title
 * @param description - Document description
 * @param content - Document content
 * @param includeMetadata - Whether to include description metadata
 * @param frontMatter - Optional frontmatter to include at the top
 * @returns Formatted markdown content
 */
export declare function createMarkdownContent(title: string, description?: string, content?: string, includeMetadata?: boolean, frontMatter?: Record<string, any>): string;
