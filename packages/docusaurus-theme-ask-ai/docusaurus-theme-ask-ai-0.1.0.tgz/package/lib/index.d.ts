import type { Plugin } from '@docusaurus/types';
export default function themeAskAi(): Plugin;
export declare function validateThemeConfig({ validate, themeConfig, }: {
    validate: (schema: any, config: any) => any;
    themeConfig: any;
}): any;
