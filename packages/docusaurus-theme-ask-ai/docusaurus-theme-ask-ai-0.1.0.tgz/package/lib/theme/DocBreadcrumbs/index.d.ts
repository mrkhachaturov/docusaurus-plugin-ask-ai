import React from 'react';
export default function DocBreadcrumbsWrapper(props: any): React.ReactNode;
