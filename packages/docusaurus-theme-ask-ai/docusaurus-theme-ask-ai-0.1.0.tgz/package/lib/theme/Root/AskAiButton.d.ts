export declare function AskAiButton(): import("react/jsx-runtime").JSX.Element | null;
