import React from 'react';
interface MenuProps {
    isOpen: boolean;
    dropDown?: boolean;
    children: React.ReactNode;
}
export declare function Menu({ isOpen, dropDown, children }: MenuProps): import("react/jsx-runtime").JSX.Element | null;
export {};
