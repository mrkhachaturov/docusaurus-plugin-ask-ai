import React from 'react';
interface MenuProps {
    isOpen: boolean;
    children: React.ReactNode;
}
export declare function Menu({ isOpen, children }: MenuProps): import("react/jsx-runtime").JSX.Element | null;
export {};
