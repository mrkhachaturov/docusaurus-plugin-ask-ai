import React from 'react';
interface MenuItemProps {
    icon: React.ReactNode;
    title: string;
    description: string;
    onClick?: () => void;
    href?: string;
}
export declare function MenuItem({ icon, title, description, onClick, href }: MenuItemProps): import("react/jsx-runtime").JSX.Element;
export declare function Divider(): import("react/jsx-runtime").JSX.Element;
export {};
