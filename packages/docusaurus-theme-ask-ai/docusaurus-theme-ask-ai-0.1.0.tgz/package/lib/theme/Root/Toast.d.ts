interface ToastProps {
    message: string | null;
    onDone: () => void;
    duration?: number;
}
export declare function Toast({ message, onDone, duration }: ToastProps): import("react/jsx-runtime").JSX.Element | null;
export {};
