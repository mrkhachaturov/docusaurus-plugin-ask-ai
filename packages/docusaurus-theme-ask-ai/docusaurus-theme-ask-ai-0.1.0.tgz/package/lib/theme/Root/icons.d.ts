import React from 'react';
interface IconProps {
    size?: number;
    className?: string;
}
export declare function SparkleIcon({ size, className }: IconProps): React.ReactElement;
interface ChevronIconProps extends IconProps {
    flipped?: boolean;
}
export declare function ChevronIcon({ size, className, flipped }: ChevronIconProps): React.ReactElement;
export declare function CopyIcon({ size, className }: IconProps): React.ReactElement;
export declare function ExternalLinkIcon({ size, className }: IconProps): React.ReactElement;
export declare function FileIcon({ size, className }: IconProps): React.ReactElement;
export declare function ChatGPTIcon({ size, className }: IconProps): React.ReactElement;
export declare function ClaudeIcon({ size, className }: IconProps): React.ReactElement;
export declare function resolveIcon(icon: string, size?: number): React.ReactNode;
export {};
