/**
 * Compute the .md URL for the current page pathname.
 */
export declare function getMdPath(pathname: string): string;
/**
 * Build a prompt string from markdown content and page title.
 * Truncates if content exceeds maxLength.
 */
export declare function buildPrompt(markdown: string, title: string, promptPrefix: string, maxLength: number, pageUrl?: string): string;
/**
 * Fetch markdown content from the .md URL.
 * Returns null on failure (404, network error).
 */
export declare function fetchMarkdown(mdPath: string): Promise<string | null>;
